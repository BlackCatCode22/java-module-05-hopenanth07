package com.hope.zoo;

public class App {
    public static void main(String[] args) {
        System.out.println("\n Welcome to my Zoo Keeper Challenge! \n");

        // How many animals do we have?
        System.out.println("\n numofAnimals is " + Animal.numofAnimals);

        // This calls the constructor in the new object
        Animal myNewAnimal = new Animal("Leo", 800, "Li09");

        System.out.println("\n myDemoAnimal name is" + myNewAnimal.getAniName());
    }
}
