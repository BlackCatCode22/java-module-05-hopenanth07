package com.hope.zoo;

// The blueprint of my Zoo Keeper Program

// Hope Nanthavongdouangsy 10/7/2025

import java.time.LocalDate;

public class Animal {

    // first constructor
    public Animal(String myName, int theWeight, String someID) {
        this.aniName = myName;
        this.weight = theWeight;
        this.aniID = someID;
    }

    // Create a static int that keeps track of the number of animals created.
    static int numofAnimals = 0;

    public Animal() {
        numofAnimals++;
    }

    public Animal(String color, LocalDate birthDate) {
        // These are fields being called upon in the parameters
        this.color = color;
        this.birthDate = birthDate;
        System.out.println("Animal " + this.color + " has been created");
    }

    public Animal(String origin, LocalDate arrivalDate, String name, String aniSound, String aSex) {
        this.origin = origin;
        this.arrivalDate = arrivalDate;
        this.name = name;
        this.aniSound = aniSound;
        this.aSex = aSex;
    }

    // There is 10 fields but numofAnimals belongs in the parameters of the animal class
    private String aniName;
    private String aniID;
    private LocalDate birthDate;// Represents the ISO 8601 date (YYYY-MM-DD)
    private String color;
    private int weight;
    private String origin;
    private LocalDate arrivalDate; // Represents the ISO 8601 date (YYYY-MM-DD)
    private String name;
    private String aniSound;
    private String aSex;

    // --- Getters ---

    public String getAniName() {
        return aniName;
    }

    public String getAnimalID() {
        return aniID;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public String getColor() {
        return color;
    }

    public int getWeight() {
        return weight;
    }

    public String getOrigin() {
        return origin;
    }

    public LocalDate getArrivalDate() {
        return arrivalDate;
    }

    public String getName() {
        return name;
    }

    public String getAniSound() {
        return aniSound;
    }

    public String getSex() {
        return aSex;
    }

    public int getNumofAnimals() {
        return numofAnimals;
    }
    
// --- Setters ---

public void setAnimalID(String animalID) {
    this.aniID = animalID;
}

public void setBirthDate(LocalDate birthDate) {
    this.birthDate = birthDate;
}

public void setColor(String color) {
    this.color = color;
}

public void setWeight(int weight) {
    this.weight = weight;
}

public void setOrigin(String origin) {
    this.origin = origin;
}

public void setArrivalDate(LocalDate arrivalDate) {
    this.arrivalDate = arrivalDate;
}

public void setName(String name) {
    this.name = name;
}

public void setAniSound(String aniSound) {
    this.aniSound = aniSound;
}

public void setSex(String aSex) {
    this.aSex = aSex;
}

public void setNumofAnimals(int numofAnimals) {
    this.numofAnimals = numofAnimals;
}
}


