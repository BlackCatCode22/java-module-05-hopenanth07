package com.hope.zoo;

import java.time.LocalDate;

public class App {
    public static void main(String[] args) {
        System.out.println("\n Welcome to my Zoo Program!\n");
        Animal myNewAnimal = new Animal();
        System.out.println("\n Animal arrival date is " + myNewAnimal.getAniArrivalDate());

        LocalDate arrivalDate = LocalDate.now();
        LocalDate birthDate = LocalDate.now();

        // Use the Full Animal constructor
        Animal anotherAnimal = new Animal("female", birthDate, 88, "Some Name","LIi06", "brown and tan", "from Zanzibar, Tanzania", arrivalDate);

        // Output anotherAnimal
        System.out.println("\n sex is: " + anotherAnimal.getAniSex());
        System.out.println("\n birthdate is: " + anotherAnimal.getAniBirthDate());
        System.out.println("\n weight is: " + anotherAnimal.getAniWeight());
        System.out.println("\n name is: " + anotherAnimal.getAniName());
        System.out.println("\n ID is: " + anotherAnimal.getAniID());
        System.out.println("\n color is: " + anotherAnimal.getAniColor());
        System.out.println("\n origin is: " + anotherAnimal.getAniOrigin());
        System.out.println("\n arrival date is: " + anotherAnimal.getAniArrivalDate());

        // Create a new Lion
        Lion myLion = new Lion();

        // Output the arrival date of my new lion
        System.out.println("\n My new lion arrived: " + myLion.getAniArrivalDate());

        // How many lions do we have? (should be 1)
        System.out.println("\n Number of lions: " + Lion.getNumOfLions());

        // How many animals do we have? (should be 3)
        System.out.println("\n Number of animals: " + Animal.getNumOfAnimals());
    }
}

